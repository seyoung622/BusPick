package com.example.buspick;

public class IPsetting {
    public static String IPaddress = "http://192.168.80.13:8765/BusPickTest/";
}
