package com.example.buspick;

public class IPsetting {
    public static String IPaddress = "http://192.168.81.174:8765/BusPickTest/";
}
