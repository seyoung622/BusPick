package com.example.buspick;

public class IPsetting {
    public static String IPaddress = "http://192.168.80.153:8765/BusPickTest/";
}
